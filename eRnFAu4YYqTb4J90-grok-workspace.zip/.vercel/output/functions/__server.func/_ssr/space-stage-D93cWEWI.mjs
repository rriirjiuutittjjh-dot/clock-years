import { o as __toESM } from "../_runtime.mjs";
import { B as require_react, _ as Link, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as LightbulbOff, i as Lightbulb, n as Volume2, t as VolumeX } from "../_libs/lucide-react.mjs";
import { i as cn, n as useTheme } from "./router-7-_lfhsP.mjs";
import { t as authClient } from "./client-B40BzJxt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/space-stage-D93cWEWI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	const { data, isPending } = authClient.useSession();
	const user = data?.user;
	return {
		user: user ? {
			id: user.id,
			displayName: user.name ?? null,
			primaryEmail: user.email ?? null,
			profileImageUrl: user.image ?? null,
			isDevFallback: false
		} : null,
		isPending
	};
}
/**
* Convenience view of `useCurrentUserState().user` for display (e.g.
* `user?.displayName ?? "Guest"`). NOTE: `null` means *loading OR signed out* —
* for redirects/guards use `useCurrentUserState()` and check `isPending`.
*/
function useCurrentUser() {
	return useCurrentUserState().user;
}
function AppChrome() {
	const { lights, setLights } = useTheme();
	const { user, isPending } = useCurrentUserState();
	const audioRef = (0, import_react.useRef)(null);
	const [musicOn, setMusicOn] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		const audio = audioRef.current;
		if (!audio) return;
		if (localStorage.getItem("system-space-music") === "false") {
			audio.pause();
			setMusicOn(false);
			return;
		}
		audio.play().catch(() => {
			const unlock = () => {
				audio.play();
				window.removeEventListener("pointerdown", unlock);
			};
			window.addEventListener("pointerdown", unlock, { once: true });
		});
	}, []);
	const toggleMusic = () => {
		const audio = audioRef.current;
		if (!audio) return;
		if (audio.paused) {
			audio.play();
			localStorage.setItem("system-space-music", "true");
			setMusicOn(true);
		} else {
			audio.pause();
			localStorage.setItem("system-space-music", "false");
			setMusicOn(false);
		}
	};
	const initial = (user?.displayName ?? user?.primaryEmail ?? "M").charAt(0).toUpperCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "pointer-events-none absolute inset-x-0 top-0 z-10 flex items-start justify-between gap-3 p-4 sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: cn("brand-pill glass pointer-events-auto"),
				children: "System Space"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-auto flex flex-wrap items-center justify-end gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "icon-btn glass",
						onClick: () => setLights(lights === "on" ? "off" : "on"),
						"aria-pressed": lights === "on",
						"aria-label": lights === "on" ? "Turn lights off" : "Turn lights on",
						children: [lights === "on" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbulb, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LightbulbOff, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "hidden sm:inline",
							children: ["Lights ", lights === "on" ? "on" : "off"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "icon-btn glass",
						onClick: toggleMusic,
						"aria-pressed": musicOn,
						"aria-label": musicOn ? "Mute music" : "Play music",
						children: [musicOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline",
							children: "Music"
						})]
					}),
					isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glass h-11 w-24 animate-pulse rounded-full" }) : user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/dashboard",
						className: "icon-btn glass max-w-[12rem]",
						children: [user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: user.profileImageUrl,
							alt: "",
							className: "size-6 rounded-full object-cover"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-6 place-items-center rounded-full bg-white/15 text-xs",
							children: initial
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden max-w-[7rem] truncate sm:inline",
							children: user.displayName ?? "Dashboard"
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							className: "btn btn-ghost",
							children: "Log in"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/register",
							className: "btn btn-primary",
							children: "Register"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
				ref: audioRef,
				loop: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("source", {
					src: "/background.mp3",
					type: "audio/mpeg"
				})
			})
		]
	});
}
var STARS = Array.from({ length: 72 }, (_, i) => {
	const s = Math.sin(i * 12.9898) * 43758.5453;
	const t = s - Math.floor(s);
	const u = Math.sin(i * 78.233) * 23421.631;
	const v = u - Math.floor(u);
	const w = Math.sin(i * 3.7) * 91.17;
	const p = w - Math.floor(w);
	return {
		left: `${(t * 100).toFixed(2)}%`,
		top: `${(v * 100).toFixed(2)}%`,
		dim: i % 3 !== 0,
		pulse: i % 11 === 0,
		delay: `${(p * 3).toFixed(2)}s`
	};
});
function Starfield() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "starfield",
		"aria-hidden": "true",
		children: STARS.map((star, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `star${star.dim ? " dim" : ""}${star.pulse ? " pulse" : ""}`,
			style: {
				left: star.left,
				top: star.top,
				animationDelay: star.delay
			}
		}, i))
	});
}
function SpaceStage({ children }) {
	const { settings } = useTheme();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-root",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-bg",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-bg-custom",
					hidden: !settings.backgroundUrl,
					style: settings.backgroundUrl ? { backgroundImage: `url(${settings.backgroundUrl})` } : void 0
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Starfield, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					className: "orbit-rings",
					viewBox: "0 0 100 100",
					preserveAspectRatio: "xMidYMid slice",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
						fill: "none",
						stroke: "rgba(232,226,255,0.11)",
						strokeWidth: "0.18",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "50",
								cy: "42",
								r: "18"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "50",
								cy: "42",
								r: "28"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "50",
								cy: "42",
								r: "40"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "50",
								cy: "42",
								r: "54"
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "lights-veil" })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-content",
			children
		})]
	});
}
//#endregion
export { useCurrentUserState as i, SpaceStage as n, useCurrentUser as r, AppChrome as t };
