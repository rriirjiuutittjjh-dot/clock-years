import { o as __toESM } from "../_runtime.mjs";
import { n as isStaff, t as DEFAULT_SETTINGS } from "./types-Cc5OTARA.mjs";
import { B as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as updateSiteSettings, n as useTheme } from "./router-7-_lfhsP.mjs";
import { i as setMemberRole, n as getMyProfile, r as listMembers, t as GatePage } from "./profiles-GeRSV8Qy.mjs";
import { n as sampleAverageColor, t as compressImage } from "./image-BTm90Y3_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-DCmwXCBC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Admin() {
	const { settings, applySettings } = useTheme();
	const [profile, setProfile] = (0, import_react.useState)(null);
	const [draft, setDraft] = (0, import_react.useState)(settings);
	const [members, setMembers] = (0, import_react.useState)([]);
	const [status, setStatus] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setDraft(settings);
	}, [settings]);
	(0, import_react.useEffect)(() => {
		getMyProfile().then(async (p) => {
			setProfile(p);
			if (isStaff(p.role)) try {
				setMembers(await listMembers());
			} catch {}
		}).catch(() => setProfile(null));
	}, []);
	function patch(next) {
		const merged = {
			...draft,
			...next
		};
		setDraft(merged);
		applySettings(merged);
	}
	async function onBackground(file) {
		if (!file) return;
		setError(null);
		try {
			const url = await compressImage(file, {
				maxEdge: 1920,
				maxBytes: 15e5,
				quality: .8
			});
			let color = draft.glassColor;
			if (draft.glassAuto) color = await sampleAverageColor(url);
			patch({
				backgroundUrl: url,
				glassColor: color
			});
		} catch (e) {
			setError(e instanceof Error ? e.message : "Could not use that image.");
		}
	}
	async function onSave(e) {
		e.preventDefault();
		setBusy(true);
		setError(null);
		setStatus(null);
		try {
			const saved = await updateSiteSettings({ data: draft });
			applySettings(saved);
			setDraft(saved);
			setStatus("Appearance saved for everyone.");
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not save.");
		} finally {
			setBusy(false);
		}
	}
	async function reset() {
		const next = { ...DEFAULT_SETTINGS };
		setDraft(next);
		applySettings(next);
	}
	async function changeRole(userId, role) {
		try {
			setMembers(await setMemberRole({ data: {
				userId,
				role
			} }));
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not change role.");
		}
	}
	if (profile && !isStaff(profile.role)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GatePage, {
		current: "/admin",
		role: profile.role,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "glass rounded-[32px] p-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold",
				children: "Admin only"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Ask the owner to promote your orbit."
			})]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GatePage, {
		current: "/admin",
		role: profile?.role ?? null,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "glass rounded-[32px] p-6 sm:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-semibold tracking-tight",
					children: "Admin"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Background, blur, and glass. Values start at 0px. Auto glass samples the upload."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-8 space-y-6",
					onSubmit: (e) => void onSave(e),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "field-label",
								children: "Background"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "btn btn-ghost cursor-pointer",
									children: ["Upload image", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "file",
										accept: "image/*",
										className: "sr-only",
										onChange: (e) => void onBackground(e.target.files?.[0])
									})]
								}), draft.backgroundUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-ghost",
									onClick: () => patch({ backgroundUrl: null }),
									children: "Clear"
								}) : null]
							}),
							draft.backgroundUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4 h-28 overflow-hidden rounded-[22px] bg-cover bg-center",
								style: {
									backgroundImage: `url(${draft.backgroundUrl})`,
									filter: `blur(${draft.backgroundBlur}px)`
								}
							}) : null
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"Background blur · ",
								draft.backgroundBlur,
								"px"
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: 0,
								max: 40,
								value: draft.backgroundBlur,
								onChange: (e) => patch({ backgroundBlur: Number(e.target.value) })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"Glass blur · ",
								draft.glassBlur,
								"px"
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: 0,
								max: 40,
								value: draft.glassBlur,
								onChange: (e) => patch({ glassBlur: Number(e.target.value) })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Glass fill · ", draft.glassOpacity] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: 0,
								max: 40,
								value: draft.glassOpacity,
								onChange: (e) => patch({ glassOpacity: Number(e.target.value) })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 sm:grid-cols-[1fr_auto] sm:items-end",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "field",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Glass color" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "color",
									value: draft.glassColor,
									onChange: (e) => patch({
										glassColor: e.target.value,
										glassAuto: false
									})
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex h-11 items-center gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: draft.glassAuto,
									onChange: (e) => patch({ glassAuto: e.target.checked })
								}), "Color glass auto"]
							})]
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-rose-300",
							children: error
						}) : null,
						status ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-ice",
							children: status
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "btn btn-primary",
								type: "submit",
								disabled: busy,
								children: busy ? "Saving…" : "Save appearance"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "btn btn-ghost",
								type: "button",
								onClick: () => void reset(),
								children: "Reset to 0"
							})]
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "glass mt-4 rounded-[32px] p-6 sm:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-semibold",
					children: "Members"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Roles: member, admin, owner. Only the owner can change them."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-6 space-y-3",
					children: members.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-wrap items-center gap-3 rounded-[18px] bg-white/5 p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-10 overflow-hidden rounded-full bg-white/10",
								children: m.avatarUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: m.avatarUrl,
									alt: "",
									className: "size-full object-cover"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid size-full place-items-center text-sm",
									children: m.displayName.charAt(0).toUpperCase()
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-medium",
									children: m.displayName
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-xs text-muted",
									children: m.email
								})]
							}),
							profile?.role === "owner" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "min-h-11 rounded-xl bg-black/30 px-3 text-sm",
								value: m.role,
								onChange: (e) => void changeRole(m.userId, e.target.value),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "member",
										children: "member"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "admin",
										children: "admin"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "owner",
										children: "owner"
									})
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs tracking-[0.16em] uppercase text-muted",
								children: m.role
							})
						]
					}, m.userId))
				})
			]
		})]
	});
}
//#endregion
export { Admin as component };
