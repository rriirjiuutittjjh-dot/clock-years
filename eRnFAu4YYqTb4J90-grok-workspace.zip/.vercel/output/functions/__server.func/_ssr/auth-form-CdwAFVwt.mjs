import { o as __toESM } from "../_runtime.mjs";
import { B as require_react, _ as Link, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as GROK_PROVIDERS } from "./server-CMbF6qJt.mjs";
import { r as signIn, t as authClient } from "./client-B40BzJxt.mjs";
import { n as SpaceStage, t as AppChrome } from "./space-stage-D93cWEWI.mjs";
import { t as AuthArt } from "./auth-art-DMCxqdv4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-form-CdwAFVwt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AuthForm({ mode }) {
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const title = mode === "login" ? "Log in" : "Create account";
	const subtitle = mode === "login" ? "Return to System Space. Your orbit is saved." : "Join as a member. The first account becomes owner.";
	async function onSubmit(e) {
		e.preventDefault();
		setError(null);
		setBusy(true);
		try {
			if (mode === "register") {
				const { error: err } = await authClient.signUp.email({
					email: email.trim(),
					password,
					name: name.trim() || email.split("@")[0] || "Member"
				});
				if (err) throw new Error(err.message || "Could not register.");
			} else {
				const { error: err } = await authClient.signIn.email({
					email: email.trim(),
					password
				});
				if (err) throw new Error(err.message || "Could not log in.");
			}
			window.location.assign("/dashboard");
		} catch (err) {
			setError(err instanceof Error ? err.message : "Something went wrong.");
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SpaceStage, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppChrome, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto grid min-h-dvh w-full max-w-5xl items-center px-4 py-24 lg:grid-cols-[1.05fr_0.95fr] lg:gap-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "glass overflow-hidden rounded-[32px]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthArt, { title })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "glass mt-6 rounded-[32px] p-6 sm:p-8 lg:mt-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-[0.28em] text-muted uppercase",
					children: "System Space"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 text-3xl font-semibold tracking-tight",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: subtitle
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-8 space-y-4",
					onSubmit: (e) => void onSubmit(e),
					children: [
						mode === "register" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: name,
								onChange: (e) => setName(e.target.value),
								autoComplete: "name",
								maxLength: 80,
								placeholder: "Your name"
							})]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Email" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "email",
								required: true,
								value: email,
								onChange: (e) => setEmail(e.target.value),
								autoComplete: "email",
								placeholder: "you@orbit.mail"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Password" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "password",
								required: true,
								minLength: 8,
								value: password,
								onChange: (e) => setPassword(e.target.value),
								autoComplete: mode === "login" ? "current-password" : "new-password",
								placeholder: "At least 8 characters"
							})]
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-rose-300",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn btn-primary w-full",
							type: "submit",
							disabled: busy,
							children: busy ? "Please wait…" : title
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center text-xs tracking-[0.18em] text-muted uppercase",
						children: "or continue with"
					}), GROK_PROVIDERS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn btn-ghost w-full",
						onClick: () => void signIn(p.providerId, { callbackURL: "/dashboard" }),
						children: ["Continue with ", p.label]
					}, p.providerId))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-sm text-muted",
					children: mode === "login" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						"New here?",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/register",
							className: "text-ink underline-offset-4 hover:underline",
							children: "Register"
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						"Already a member?",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							className: "text-ink underline-offset-4 hover:underline",
							children: "Log in"
						})
					] })
				})
			]
		})]
	})] });
}
//#endregion
export { AuthForm as t };
