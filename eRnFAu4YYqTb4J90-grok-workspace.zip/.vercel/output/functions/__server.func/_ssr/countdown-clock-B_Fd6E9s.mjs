import { o as __toESM } from "../_runtime.mjs";
import { B as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/countdown-clock-B_Fd6E9s.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var UNITS = [
	"days",
	"hours",
	"minutes",
	"seconds"
];
var UNIT_LABELS = {
	days: "Days",
	hours: "Hours",
	minutes: "Minutes",
	seconds: "Seconds"
};
function nextNewYear(from) {
	return new Date(from.getFullYear() + 1, 0, 1, 0, 0, 0, 0);
}
function splitMs(ms) {
	const total = Math.max(0, Math.floor(ms / 1e3));
	return {
		days: Math.floor(total / 86400),
		hours: Math.floor(total / 3600 % 24),
		minutes: Math.floor(total / 60 % 60),
		seconds: total % 60
	};
}
function yearProgress(now) {
	const start = new Date(now.getFullYear(), 0, 1).getTime();
	const end = new Date(now.getFullYear() + 1, 0, 1).getTime();
	return (now.getTime() - start) / (end - start) * 100;
}
var pad2 = (n) => String(n).padStart(2, "0");
function formatTarget(target) {
	return new Intl.DateTimeFormat(void 0, {
		month: "long",
		day: "numeric",
		year: "numeric"
	}).format(target);
}
function formatMeta(target) {
	const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || "local time";
	return `Rings in ${new Intl.DateTimeFormat(void 0, {
		weekday: "short",
		day: "numeric",
		month: "short",
		year: "numeric",
		hour: "2-digit",
		minute: "2-digit",
		hour12: false
	}).format(target)} · ${tz}`;
}
function formatNow(now) {
	return new Intl.DateTimeFormat(void 0, {
		hour: "numeric",
		minute: "2-digit",
		second: "2-digit",
		hour12: true
	}).format(now);
}
function CountdownClock({ parts, compact = false }) {
	const wide = parts.days >= 100;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `countdown${wide ? " wide" : ""}`,
		role: "timer",
		"aria-label": `${parts.days} days ${pad2(parts.hours)} hours ${pad2(parts.minutes)} minutes ${pad2(parts.seconds)} seconds`,
		children: UNITS.map((unit, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [i > 0 && !compact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "colon",
			"aria-hidden": "true",
			children: ":"
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "unit",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "num",
				children: unit === "days" ? String(parts.days).padStart(2, "0") : pad2(parts[unit])
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "unit-label",
				children: UNIT_LABELS[unit]
			})]
		})] }, unit))
	});
}
//#endregion
export { nextNewYear as a, yearProgress as c, formatTarget as i, formatMeta as n, pad2 as o, formatNow as r, splitMs as s, CountdownClock as t };
