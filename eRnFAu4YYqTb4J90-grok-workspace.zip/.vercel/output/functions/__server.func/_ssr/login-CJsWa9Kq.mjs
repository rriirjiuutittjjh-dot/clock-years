import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as AuthForm } from "./auth-form-CdwAFVwt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-CJsWa9Kq.js
var import_jsx_runtime = require_jsx_runtime();
function Login() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthForm, { mode: "login" });
}
//#endregion
export { Login as component };
