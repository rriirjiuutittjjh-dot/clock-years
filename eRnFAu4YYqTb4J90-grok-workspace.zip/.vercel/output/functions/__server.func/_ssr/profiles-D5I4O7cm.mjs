import { r as createServerFn } from "./ssr.mjs";
import { D as _enum, F as object, R as string } from "../_libs/@better-auth/core+[...].mjs";
import { i as getSql, t as authMiddleware } from "./middleware-DADLbS_p.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profiles-D5I4O7cm.js
function asProfile(row) {
	return {
		userId: row.user_id,
		displayName: row.display_name,
		bio: row.bio,
		avatarUrl: row.avatar_url,
		role: row.role,
		email: row.email
	};
}
async function loadMembers() {
	return (await (await getSql())`
    select p.user_id, p.display_name, p.bio, p.avatar_url, p.role, u.email
    from profiles p
    left join "user" u on u.id = p.user_id
    order by
      case p.role when 'owner' then 0 when 'admin' then 1 else 2 end,
      p.created_at asc
  `).map(asProfile);
}
async function ensureProfile(userId) {
	const sql = await getSql();
	const existing = await sql`
    select p.user_id, p.display_name, p.bio, p.avatar_url, p.role, u.email
    from profiles p
    left join "user" u on u.id = p.user_id
    where p.user_id = ${userId}
  `;
	if (existing[0]) return asProfile(existing[0]);
	const auth = (await sql`
    select name, email, image from "user" where id = ${userId}
  `)[0];
	const role = ((await sql`select count(*)::int as n from profiles where role = 'owner'`)[0]?.n ?? 0) === 0 ? "owner" : "member";
	const displayName = auth?.name?.trim() || auth?.email?.split("@")[0] || "Member";
	const avatar = auth?.image ?? null;
	await sql`
    insert into profiles (user_id, display_name, bio, avatar_url, role)
    values (${userId}, ${displayName}, ${""}, ${avatar}, ${role})
    on conflict (user_id) do nothing
  `;
	const created = await sql`
    select p.user_id, p.display_name, p.bio, p.avatar_url, p.role, u.email
    from profiles p
    left join "user" u on u.id = p.user_id
    where p.user_id = ${userId}
  `;
	if (!created[0]) return {
		userId,
		displayName,
		bio: "",
		avatarUrl: avatar,
		role,
		email: auth?.email ?? null
	};
	return asProfile(created[0]);
}
var getMyProfile_createServerFn_handler = createServerRpc({
	id: "32a9729b35a4e5abe3a68a0ba7604c857d34cb6cca8a48e59908fc12f41ac088",
	name: "getMyProfile",
	filename: "src/lib/server/profiles.ts"
}, (opts) => getMyProfile.__executeServer(opts));
var getMyProfile = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getMyProfile_createServerFn_handler, async ({ context }) => ensureProfile(context.userId));
var profileUpdate = object({
	displayName: string().trim().min(1).max(80),
	bio: string().max(280),
	avatarUrl: string().nullable()
});
var updateMyProfile_createServerFn_handler = createServerRpc({
	id: "d1c924a44c4baae790f3becea8723eb8eba95d91aaab9723fb5ea523a4b36439",
	name: "updateMyProfile",
	filename: "src/lib/server/profiles.ts"
}, (opts) => updateMyProfile.__executeServer(opts));
var updateMyProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => profileUpdate.parse(input)).handler(updateMyProfile_createServerFn_handler, async ({ context, data }) => {
	if (data.avatarUrl && data.avatarUrl.length > 7e5) throw new Error("Profile image is too large.");
	await ensureProfile(context.userId);
	await (await getSql())`
      update profiles
      set display_name = ${data.displayName},
          bio = ${data.bio},
          avatar_url = ${data.avatarUrl},
          updated_at = now()
      where user_id = ${context.userId}
    `;
	return ensureProfile(context.userId);
});
var listMembers_createServerFn_handler = createServerRpc({
	id: "6524a69bc45707c7af14e386ccc4f907c376f76cf2f59f61e26707e04c0b8ab0",
	name: "listMembers",
	filename: "src/lib/server/profiles.ts"
}, (opts) => listMembers.__executeServer(opts));
var listMembers = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listMembers_createServerFn_handler, async ({ context }) => {
	const me = await ensureProfile(context.userId);
	if (me.role !== "admin" && me.role !== "owner") throw new Error("Admin access required.");
	return loadMembers();
});
var roleUpdate = object({
	userId: string().min(1),
	role: _enum([
		"member",
		"admin",
		"owner"
	])
});
var setMemberRole_createServerFn_handler = createServerRpc({
	id: "39cdca4700c482c56d16f29e82e300a68bdfa305b4dec7170284a2c01ffb15ec",
	name: "setMemberRole",
	filename: "src/lib/server/profiles.ts"
}, (opts) => setMemberRole.__executeServer(opts));
var setMemberRole = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => roleUpdate.parse(input)).handler(setMemberRole_createServerFn_handler, async ({ context, data }) => {
	if ((await ensureProfile(context.userId)).role !== "owner") throw new Error("Only the owner can change roles.");
	if (data.userId === context.userId && data.role !== "owner") throw new Error("You cannot demote yourself.");
	const sql = await getSql();
	const target = await sql`select role from profiles where user_id = ${data.userId}`;
	if (!target[0]) throw new Error("Member not found.");
	if (target[0].role === "owner" && data.role !== "owner") {
		if (((await sql`select count(*)::int as n from profiles where role = 'owner'`)[0]?.n ?? 0) <= 1) throw new Error("Keep at least one owner.");
	}
	await sql`
      update profiles set role = ${data.role}, updated_at = now()
      where user_id = ${data.userId}
    `;
	return loadMembers();
});
//#endregion
export { getMyProfile_createServerFn_handler, listMembers_createServerFn_handler, setMemberRole_createServerFn_handler, updateMyProfile_createServerFn_handler };
