import { r as clamp } from "./router-7-_lfhsP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/image-BTm90Y3_.js
async function compressImage(file, opts) {
	const quality = opts.quality ?? .82;
	const bitmap = await loadBitmap(file);
	const scale = Math.min(1, opts.maxEdge / Math.max(bitmap.width, bitmap.height));
	const w = Math.max(1, Math.round(bitmap.width * scale));
	const h = Math.max(1, Math.round(bitmap.height * scale));
	const canvas = document.createElement("canvas");
	canvas.width = w;
	canvas.height = h;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Could not process the image.");
	ctx.drawImage(bitmap, 0, 0, w, h);
	bitmap.close?.();
	let q = quality;
	let url = canvas.toDataURL("image/jpeg", q);
	while (url.length > opts.maxBytes && q > .4) {
		q -= .08;
		url = canvas.toDataURL("image/jpeg", q);
	}
	if (url.length > opts.maxBytes) throw new Error("Image is still too large after compression. Try a smaller file.");
	return url;
}
async function sampleAverageColor(dataUrl) {
	const img = await loadImage(dataUrl);
	const canvas = document.createElement("canvas");
	canvas.width = 24;
	canvas.height = 24;
	const ctx = canvas.getContext("2d");
	if (!ctx) return "#ffffff";
	ctx.drawImage(img, 0, 0, 24, 24);
	const { data } = ctx.getImageData(0, 0, 24, 24);
	let r = 0;
	let g = 0;
	let b = 0;
	let n = 0;
	for (let i = 0; i < data.length; i += 4) {
		if ((data[i + 3] ?? 0) < 20) continue;
		r += data[i] ?? 0;
		g += data[i + 1] ?? 0;
		b += data[i + 2] ?? 0;
		n += 1;
	}
	if (!n) return "#c8c4e8";
	r = Math.round(r / n);
	g = Math.round(g / n);
	b = Math.round(b / n);
	const lift = 90;
	if (r + g + b < 120) {
		r = clamp(r + lift, 0, 255);
		g = clamp(g + lift, 0, 255);
		b = clamp(b + lift, 0, 255);
	}
	return `#${[
		r,
		g,
		b
	].map((c) => c.toString(16).padStart(2, "0")).join("")}`;
}
function loadImage(src) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.onload = () => resolve(img);
		img.onerror = () => reject(/* @__PURE__ */ new Error("Could not read the image."));
		img.src = src;
	});
}
async function loadBitmap(file) {
	if (typeof createImageBitmap === "function") return createImageBitmap(file);
	const url = URL.createObjectURL(file);
	try {
		const img = await loadImage(url);
		const canvas = document.createElement("canvas");
		canvas.width = img.naturalWidth;
		canvas.height = img.naturalHeight;
		const ctx = canvas.getContext("2d");
		if (!ctx) throw new Error("Could not process the image.");
		ctx.drawImage(img, 0, 0);
		return canvas;
	} finally {
		URL.revokeObjectURL(url);
	}
}
//#endregion
export { sampleAverageColor as n, compressImage as t };
