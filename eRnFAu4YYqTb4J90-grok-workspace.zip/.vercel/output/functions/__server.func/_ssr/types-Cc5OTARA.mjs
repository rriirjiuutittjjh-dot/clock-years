//#region node_modules/.nitro/vite/services/ssr/assets/types-Cc5OTARA.js
var DEFAULT_SETTINGS = {
	backgroundUrl: null,
	backgroundBlur: 0,
	glassBlur: 0,
	glassOpacity: 10,
	glassColor: "#ffffff",
	glassAuto: true
};
function isStaff(role) {
	return role === "admin" || role === "owner";
}
//#endregion
export { isStaff as n, DEFAULT_SETTINGS as t };
