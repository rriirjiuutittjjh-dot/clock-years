import { o as __toESM } from "../_runtime.mjs";
import { B as require_react, _ as Link, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as getMyProfile, t as GatePage } from "./profiles-GeRSV8Qy.mjs";
import { n as DashboardMark } from "./auth-art-DMCxqdv4.mjs";
import { a as nextNewYear, c as yearProgress, s as splitMs, t as CountdownClock } from "./countdown-clock-B_Fd6E9s.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-C32i2VGN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Dashboard() {
	const [profile, setProfile] = (0, import_react.useState)(null);
	const [parts, setParts] = (0, import_react.useState)({
		days: 0,
		hours: 0,
		minutes: 0,
		seconds: 0
	});
	const [pct, setPct] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		getMyProfile().then(setProfile).catch(() => setProfile(null));
		const tick = () => {
			const now = /* @__PURE__ */ new Date();
			setParts(splitMs(nextNewYear(now).getTime() - now.getTime()));
			setPct(yearProgress(now));
		};
		tick();
		const id = window.setInterval(tick, 1e3);
		return () => window.clearInterval(id);
	}, []);
	const role = profile?.role ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GatePage, {
		current: "/dashboard",
		role,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "glass rounded-[32px] p-6 sm:p-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardMark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-[0.28em] text-muted uppercase",
							children: "Member orbit"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-1 text-3xl font-semibold tracking-tight",
							children: profile ? `Welcome, ${profile.displayName}` : "Dashboard"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: profile?.bio || "Set a bio in Account to leave a trace in the system."
						})
					] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-white/10 px-3 py-1 text-xs tracking-[0.16em] uppercase",
						children: role ?? "member"
					}), profile?.email ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-white/8 px-3 py-1 text-xs text-muted",
						children: profile.email
					}) : null]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "glass mt-4 rounded-[32px] p-6 sm:p-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm tracking-[0.2em] text-muted uppercase",
						children: "Countdown"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CountdownClock, { parts })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto mt-6 h-1.5 max-w-md overflow-hidden rounded-full bg-white/10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full rounded-full bg-ice",
							style: { width: `${pct.toFixed(2)}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-center text-xs text-muted",
						children: [pct.toFixed(2), "% of this year has passed"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/settings",
					className: "glass block rounded-[28px] p-6 no-underline transition-colors hover:bg-white/6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-medium",
						children: "Account"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Avatar, bio, and password."
					})]
				}), role === "admin" || role === "owner" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/admin",
					className: "glass block rounded-[28px] p-6 no-underline transition-colors hover:bg-white/6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-medium",
						children: "Admin"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Background, blur, and glass."
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "glass rounded-[28px] p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-medium",
						children: "Role"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Members explore System Space. Admins shape the sky. Owners hold the keys."
					})]
				})]
			})
		]
	});
}
//#endregion
export { Dashboard as component };
