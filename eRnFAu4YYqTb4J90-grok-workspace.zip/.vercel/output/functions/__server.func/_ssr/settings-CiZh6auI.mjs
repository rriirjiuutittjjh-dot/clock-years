import { o as __toESM } from "../_runtime.mjs";
import { B as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as authClient } from "./client-B40BzJxt.mjs";
import { a as updateMyProfile, n as getMyProfile, t as GatePage } from "./profiles-GeRSV8Qy.mjs";
import { t as compressImage } from "./image-BTm90Y3_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-CiZh6auI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Settings() {
	const [profile, setProfile] = (0, import_react.useState)(null);
	const [displayName, setDisplayName] = (0, import_react.useState)("");
	const [bio, setBio] = (0, import_react.useState)("");
	const [avatarUrl, setAvatarUrl] = (0, import_react.useState)(null);
	const [status, setStatus] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [currentPassword, setCurrentPassword] = (0, import_react.useState)("");
	const [newPassword, setNewPassword] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)("");
	const [pwStatus, setPwStatus] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		getMyProfile().then((p) => {
			setProfile(p);
			setDisplayName(p.displayName);
			setBio(p.bio);
			setAvatarUrl(p.avatarUrl);
		}).catch(() => setError("Could not load your account."));
	}, []);
	async function onAvatar(file) {
		if (!file) return;
		setError(null);
		try {
			const url = await compressImage(file, {
				maxEdge: 320,
				maxBytes: 42e4,
				quality: .84
			});
			setAvatarUrl(url);
		} catch (e) {
			setError(e instanceof Error ? e.message : "Could not use that image.");
		}
	}
	async function onSave(e) {
		e.preventDefault();
		setBusy(true);
		setError(null);
		setStatus(null);
		try {
			const next = await updateMyProfile({ data: {
				displayName: displayName.trim(),
				bio: bio.trim(),
				avatarUrl
			} });
			setProfile(next);
			setStatus("Account saved.");
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not save.");
		} finally {
			setBusy(false);
		}
	}
	async function onPassword(e) {
		e.preventDefault();
		setPwStatus(null);
		if (newPassword !== confirm) {
			setPwStatus("New passwords do not match.");
			return;
		}
		if (newPassword.length < 8) {
			setPwStatus("Use at least 8 characters.");
			return;
		}
		const { error: err } = await authClient.changePassword({
			currentPassword,
			newPassword,
			revokeOtherSessions: false
		});
		if (err) {
			setPwStatus(err.message || "Could not update password. Email accounts only.");
			return;
		}
		setCurrentPassword("");
		setNewPassword("");
		setConfirm("");
		setPwStatus("Password updated.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GatePage, {
		current: "/settings",
		role: profile?.role ?? null,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "glass rounded-[32px] p-6 sm:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-semibold tracking-tight",
					children: "Account"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Profile, bio, and password for your orbit."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-8 space-y-5",
					onSubmit: (e) => void onSave(e),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-20 overflow-hidden rounded-full bg-white/10",
									children: avatarUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: avatarUrl,
										alt: "",
										className: "size-full object-cover"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid size-full place-items-center text-xl",
										children: (displayName || "M").charAt(0).toUpperCase()
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "btn btn-ghost cursor-pointer",
									children: ["Upload photo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "file",
										accept: "image/*",
										className: "sr-only",
										onChange: (e) => void onAvatar(e.target.files?.[0])
									})]
								}),
								avatarUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-ghost",
									onClick: () => setAvatarUrl(null),
									children: "Remove"
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Display name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: displayName,
								onChange: (e) => setDisplayName(e.target.value),
								maxLength: 80,
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Bio" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: bio,
								onChange: (e) => setBio(e.target.value),
								maxLength: 280,
								placeholder: "A short note from your orbit."
							})]
						}),
						profile?.email ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Email" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: profile.email,
								readOnly: true
							})]
						}) : null,
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-rose-300",
							children: error
						}) : null,
						status ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-ice",
							children: status
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn btn-primary",
							type: "submit",
							disabled: busy,
							children: busy ? "Saving…" : "Save profile"
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "glass mt-4 rounded-[32px] p-6 sm:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-semibold",
					children: "Password"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "For email accounts. Google and X sign-in keep their own credentials."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-6 space-y-4",
					onSubmit: (e) => void onPassword(e),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Current password" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "password",
								autoComplete: "current-password",
								value: currentPassword,
								onChange: (e) => setCurrentPassword(e.target.value),
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "New password" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "password",
								autoComplete: "new-password",
								minLength: 8,
								value: newPassword,
								onChange: (e) => setNewPassword(e.target.value),
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Confirm password" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "password",
								autoComplete: "new-password",
								value: confirm,
								onChange: (e) => setConfirm(e.target.value),
								required: true
							})]
						}),
						pwStatus ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: pwStatus
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn btn-primary",
							type: "submit",
							children: "Update password"
						})
					]
				})
			]
		})]
	});
}
//#endregion
export { Settings as component };
