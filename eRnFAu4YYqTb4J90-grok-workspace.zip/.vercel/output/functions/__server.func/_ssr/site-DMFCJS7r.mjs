import { t as DEFAULT_SETTINGS } from "./types-Cc5OTARA.mjs";
import { r as createServerFn } from "./ssr.mjs";
import { A as boolean, F as object, P as number, R as string } from "../_libs/@better-auth/core+[...].mjs";
import { i as getSql, t as authMiddleware } from "./middleware-DADLbS_p.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/site-DMFCJS7r.js
var HEX = /^#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})$/;
function asBool(v) {
	if (v === true || v === "t" || v === "true" || v === 1 || v === "1") return true;
	return false;
}
function asSettings(row) {
	if (!row) return DEFAULT_SETTINGS;
	return {
		backgroundUrl: row.background_url,
		backgroundBlur: Number(row.background_blur) || 0,
		glassBlur: Number(row.glass_blur) || 0,
		glassOpacity: Number(row.glass_opacity) || 0,
		glassColor: HEX.test(row.glass_color) ? row.glass_color : DEFAULT_SETTINGS.glassColor,
		glassAuto: asBool(row.glass_auto)
	};
}
var getPublicSettings_createServerFn_handler = createServerRpc({
	id: "075f7f6cc9db897c3f9816699078bd0e83d23b3d7a32b63e565165a9ac5730a5",
	name: "getPublicSettings",
	filename: "src/lib/server/site.ts"
}, (opts) => getPublicSettings.__executeServer(opts));
var getPublicSettings = createServerFn({ method: "GET" }).handler(getPublicSettings_createServerFn_handler, async () => {
	try {
		return asSettings((await (await getSql())`select background_url, background_blur, glass_blur, glass_opacity, glass_color, glass_auto from site_settings where id = 1`)[0]);
	} catch {
		return DEFAULT_SETTINGS;
	}
});
async function requireStaff(userId) {
	const role = (await (await getSql())`select role from profiles where user_id = ${userId}`)[0]?.role ?? "member";
	if (role !== "admin" && role !== "owner") throw new Error("Admin access required.");
	return role;
}
var updateSchema = object({
	backgroundUrl: string().nullable(),
	backgroundBlur: number().int().min(0).max(40),
	glassBlur: number().int().min(0).max(40),
	glassOpacity: number().int().min(0).max(40),
	glassColor: string().regex(HEX),
	glassAuto: boolean()
});
var updateSiteSettings_createServerFn_handler = createServerRpc({
	id: "60c89cc2fa375051b56ddb5ee61be28dc0a751eb2d03c1dbb8af36e269e5880d",
	name: "updateSiteSettings",
	filename: "src/lib/server/site.ts"
}, (opts) => updateSiteSettings.__executeServer(opts));
var updateSiteSettings = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => updateSchema.parse(input)).handler(updateSiteSettings_createServerFn_handler, async ({ context, data }) => {
	await requireStaff(context.userId);
	if (data.backgroundUrl && data.backgroundUrl.length > 18e5) throw new Error("Background image is too large.");
	await (await getSql())`
      update site_settings set
        background_url = ${data.backgroundUrl},
        background_blur = ${data.backgroundBlur},
        glass_blur = ${data.glassBlur},
        glass_opacity = ${data.glassOpacity},
        glass_color = ${data.glassColor},
        glass_auto = ${data.glassAuto},
        updated_at = now()
      where id = 1
    `;
	return {
		backgroundUrl: data.backgroundUrl,
		backgroundBlur: data.backgroundBlur,
		glassBlur: data.glassBlur,
		glassOpacity: data.glassOpacity,
		glassColor: data.glassColor,
		glassAuto: data.glassAuto
	};
});
//#endregion
export { getPublicSettings_createServerFn_handler, updateSiteSettings_createServerFn_handler };
