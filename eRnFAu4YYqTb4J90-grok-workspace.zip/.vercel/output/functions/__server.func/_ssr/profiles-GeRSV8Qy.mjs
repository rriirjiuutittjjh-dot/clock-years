import { o as __toESM } from "../_runtime.mjs";
import { n as isStaff } from "./types-Cc5OTARA.mjs";
import { B as require_react, _ as Link, b as require_jsx_runtime, v as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as createServerFn } from "./ssr.mjs";
import { D as _enum, F as object, R as string } from "../_libs/@better-auth/core+[...].mjs";
import { t as authMiddleware } from "./middleware-DADLbS_p.mjs";
import { a as hasGateSessionMarker } from "./server-CMbF6qJt.mjs";
import { i as cn, o as createSsrRpc } from "./router-7-_lfhsP.mjs";
import { i as signOut } from "./client-B40BzJxt.mjs";
import { i as useCurrentUserState, n as SpaceStage, r as useCurrentUser, t as AppChrome } from "./space-stage-D93cWEWI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profiles-GeRSV8Qy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Auth state components — plain wrappers around `useCurrentUserState()`.
*
* With auth on, visitors are signed out until they authenticate — in the sandbox
* live preview too, which does real sign-in. The shared dev user appears only
* when auth is disabled (`VITE_AUTH_ENABLED=false`, the shipped default).
* While the session is still resolving, gates that care about signed-out state
* render nothing so there's no signed-out flash on hard reload.
*/
/** Where `RedirectToSignIn` sends signed-out visitors. Create this route. */
var SIGN_IN_PATH = "/login";
/**
* Client-side redirect to the sign-in route (TanStack `<Navigate>` — NOT a full
* `window.location` reload). A hard navigation re-bootstraps the SPA and re-runs
* session loading, which feels like a second "Loading…" on /login.
*
* Guard routes by waiting out `isPending` first (see `use-current-user`), then
* render this.
*/
function RedirectToSignIn({ to = SIGN_IN_PATH }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to });
}
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
var links = [
	{
		to: "/",
		label: "Home"
	},
	{
		to: "/dashboard",
		label: "Dashboard"
	},
	{
		to: "/settings",
		label: "Account"
	}
];
function MemberNav({ role, current }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
		className: "glass flex flex-wrap items-center gap-1 rounded-[22px] p-2",
		children: [
			links.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: l.to,
				className: cn("rounded-xl px-3 py-2 text-sm font-medium transition-colors", current === l.to ? "bg-white/12 text-ink" : "text-muted hover:text-ink"),
				children: l.label
			}, l.to)),
			isStaff(role) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/admin",
				className: cn("rounded-xl px-3 py-2 text-sm font-medium transition-colors", current === "/admin" ? "bg-white/12 text-ink" : "text-muted hover:text-ink"),
				children: "Admin"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "ml-auto pl-2 text-sm [&_button]:text-muted [&_button]:no-underline hover:[&_button]:text-ink",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {})
			})
		]
	});
}
function GatePage({ current, role, children }) {
	const { user, isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SpaceStage, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppChrome, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "mx-auto max-w-4xl px-4 py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glass h-40 animate-pulse rounded-[32px]" })
	})] });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SpaceStage, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppChrome, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto w-full max-w-4xl px-4 pb-16 pt-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemberNav, {
			role,
			current
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6",
			children
		})]
	})] });
}
var getMyProfile = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("32a9729b35a4e5abe3a68a0ba7604c857d34cb6cca8a48e59908fc12f41ac088"));
var profileUpdate = object({
	displayName: string().trim().min(1).max(80),
	bio: string().max(280),
	avatarUrl: string().nullable()
});
var updateMyProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => profileUpdate.parse(input)).handler(createSsrRpc("d1c924a44c4baae790f3becea8723eb8eba95d91aaab9723fb5ea523a4b36439"));
var listMembers = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("6524a69bc45707c7af14e386ccc4f907c376f76cf2f59f61e26707e04c0b8ab0"));
var roleUpdate = object({
	userId: string().min(1),
	role: _enum([
		"member",
		"admin",
		"owner"
	])
});
var setMemberRole = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => roleUpdate.parse(input)).handler(createSsrRpc("39cdca4700c482c56d16f29e82e300a68bdfa305b4dec7170284a2c01ffb15ec"));
//#endregion
export { updateMyProfile as a, setMemberRole as i, getMyProfile as n, listMembers as r, GatePage as t };
