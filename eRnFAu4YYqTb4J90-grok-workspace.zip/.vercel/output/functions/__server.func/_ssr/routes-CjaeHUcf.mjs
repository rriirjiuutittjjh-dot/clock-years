import { o as __toESM } from "../_runtime.mjs";
import { B as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as SpaceStage, t as AppChrome } from "./space-stage-D93cWEWI.mjs";
import { a as nextNewYear, c as yearProgress, i as formatTarget, n as formatMeta, o as pad2, r as formatNow, s as splitMs, t as CountdownClock } from "./countdown-clock-B_Fd6E9s.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CjaeHUcf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var COLORS = [
	"#ffd166",
	"#ff5c8a",
	"#22d3ee",
	"#c4b5fd",
	"#a3e635",
	"#ffffff"
];
function reduced() {
	return typeof window !== "undefined" && window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
}
function Fireworks({ active }) {
	const canvasRef = (0, import_react.useRef)(null);
	const particles = (0, import_react.useRef)([]);
	const raf = (0, import_react.useRef)(0);
	const running = (0, import_react.useRef)(false);
	const burst = (0, import_react.useCallback)((x, y) => {
		const color = COLORS[Math.random() * COLORS.length | 0] ?? COLORS[0];
		const count = reduced() ? 18 : 72;
		for (let i = 0; i < count; i++) {
			const angle = Math.PI * 2 * i / count + Math.random() * .3;
			const speed = 2 + Math.random() * 5;
			particles.current.push({
				x,
				y,
				vx: Math.cos(angle) * speed,
				vy: Math.sin(angle) * speed,
				life: 1,
				decay: .01 + Math.random() * .012,
				size: 1.1 + Math.random() * 2,
				color
			});
		}
	}, []);
	const loop = (0, import_react.useCallback)(() => {
		const canvas = canvasRef.current;
		const ctx = canvas?.getContext("2d");
		if (!canvas || !ctx) return;
		const w = window.innerWidth;
		const h = window.innerHeight;
		ctx.globalCompositeOperation = "destination-out";
		ctx.fillStyle = "rgba(0,0,0,0.18)";
		ctx.fillRect(0, 0, w, h);
		ctx.globalCompositeOperation = "lighter";
		const list = particles.current;
		for (let i = list.length - 1; i >= 0; i--) {
			const p = list[i];
			if (!p) continue;
			p.vy += .06;
			p.vx *= .985;
			p.vy *= .985;
			p.x += p.vx;
			p.y += p.vy;
			p.life -= p.decay;
			if (p.life <= 0) {
				list.splice(i, 1);
				continue;
			}
			ctx.globalAlpha = Math.max(0, p.life);
			ctx.fillStyle = p.color;
			ctx.beginPath();
			ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
			ctx.fill();
		}
		ctx.globalAlpha = 1;
		if (running.current && Math.random() < .04) burst(w * (.15 + Math.random() * .7), h * (.12 + Math.random() * .42));
		if (list.length || running.current) raf.current = requestAnimationFrame(loop);
		else ctx.clearRect(0, 0, w, h);
	}, [burst]);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const resize = () => {
			const ctx = canvas.getContext("2d");
			if (!ctx) return;
			const dpr = Math.min(window.devicePixelRatio || 1, 2);
			canvas.width = Math.floor(window.innerWidth * dpr);
			canvas.height = Math.floor(window.innerHeight * dpr);
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		};
		resize();
		window.addEventListener("resize", resize);
		return () => window.removeEventListener("resize", resize);
	}, []);
	(0, import_react.useEffect)(() => {
		running.current = active;
		if (active) {
			const w = window.innerWidth;
			const h = window.innerHeight;
			burst(w * .3, h * .28);
			burst(w * .7, h * .24);
			raf.current = requestAnimationFrame(loop);
		}
		return () => {
			running.current = false;
			cancelAnimationFrame(raf.current);
		};
	}, [
		active,
		burst,
		loop
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref: canvasRef,
		className: "fx",
		"aria-hidden": "true"
	});
}
var PLANETS = [
	{
		name: "Mercury",
		r: 5.2,
		fill: "#b7a48c",
		x: 268
	},
	{
		name: "Venus",
		r: 8.4,
		fill: "#e2c07a",
		x: 312
	},
	{
		name: "Earth",
		r: 8.8,
		fill: "#4f8fce",
		x: 358
	},
	{
		name: "Mars",
		r: 6.4,
		fill: "#c45c3e",
		x: 400
	},
	{
		name: "Jupiter",
		r: 16,
		fill: "#d9a066",
		x: 456
	},
	{
		name: "Saturn",
		r: 13.5,
		fill: "#e6d3a3",
		x: 520,
		rings: true
	},
	{
		name: "Uranus",
		r: 10,
		fill: "#7ec8c8",
		x: 580
	},
	{
		name: "Neptune",
		r: 9.6,
		fill: "#4b6fd6",
		x: 632
	}
];
function SolarSystem() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "solar-wrap",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			className: "solar-svg",
			viewBox: "0 0 900 220",
			role: "img",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", { children: "Solar system" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("defs", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("radialGradient", {
					id: "sunGlow",
					cx: "50%",
					cy: "50%",
					r: "50%",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0%",
							stopColor: "#fff6d2"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "42%",
							stopColor: "#f0d48a"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "100%",
							stopColor: "#f0d48a",
							stopOpacity: "0"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("radialGradient", {
					id: "sunCore",
					cx: "38%",
					cy: "38%",
					r: "62%",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0%",
							stopColor: "#fff4c8"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "55%",
							stopColor: "#f0d48a"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "100%",
							stopColor: "#d7a24a"
						})
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
					fill: "none",
					stroke: "rgba(232,226,255,0.16)",
					strokeWidth: "1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
							cx: "450",
							cy: "110",
							rx: "410",
							ry: "92"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
							cx: "450",
							cy: "110",
							rx: "330",
							ry: "70"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
							cx: "450",
							cy: "110",
							rx: "240",
							ry: "48"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
							cx: "450",
							cy: "110",
							rx: "150",
							ry: "28"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "196",
					cy: "110",
					r: "52",
					fill: "url(#sunGlow)",
					opacity: "0.9"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "196",
					cy: "110",
					r: "28",
					fill: "url(#sunCore)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "186",
					cy: "100",
					r: "7",
					fill: "#fff8dc",
					opacity: "0.45"
				}),
				PLANETS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
					transform: `translate(${p.x} 110)`,
					children: [
						"rings" in p && p.rings ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
							cx: "0",
							cy: "0",
							rx: "24",
							ry: "7",
							fill: "none",
							stroke: "#e8d9b0",
							strokeWidth: "2.2",
							opacity: "0.85",
							transform: "rotate(-18)"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							r: p.r,
							fill: p.fill
						}),
						p.name === "Earth" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "-2",
							cy: "-1",
							r: "3.2",
							fill: "#3d8a62",
							opacity: "0.85"
						}) : null,
						p.name === "Jupiter" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
							cx: "0",
							cy: "-4",
							rx: "14",
							ry: "3.2",
							fill: "#c9844c",
							opacity: "0.55"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
							cx: "0",
							cy: "5",
							rx: "13",
							ry: "2.4",
							fill: "#efd0a0",
							opacity: "0.45"
						})] }) : null
					]
				}, p.name))
			]
		})
	});
}
function HomeView() {
	const targetRef = (0, import_react.useRef)(/* @__PURE__ */ new Date(0));
	const partyTimer = (0, import_react.useRef)(null);
	const partyStarted = (0, import_react.useRef)(false);
	const lastSecond = (0, import_react.useRef)(null);
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [parts, setParts] = (0, import_react.useState)({
		days: 0,
		hours: 0,
		minutes: 0,
		seconds: 0
	});
	const [targetLabel, setTargetLabel] = (0, import_react.useState)("January 1");
	const [meta, setMeta] = (0, import_react.useState)("");
	const [clockNow, setClockNow] = (0, import_react.useState)("");
	const [progress, setProgress] = (0, import_react.useState)(0);
	const [progressLabel, setProgressLabel] = (0, import_react.useState)("");
	const [party, setParty] = (0, import_react.useState)(false);
	const [partySub, setPartySub] = (0, import_react.useState)("");
	const [trueMidnight, setTrueMidnight] = (0, import_react.useState)(false);
	const [nextYearLabel, setNextYearLabel] = (0, import_react.useState)("");
	const [fx, setFx] = (0, import_react.useState)(false);
	const [sr, setSr] = (0, import_react.useState)("");
	const describe = (0, import_react.useCallback)(() => {
		setTargetLabel(formatTarget(targetRef.current));
		setMeta(formatMeta(targetRef.current));
	}, []);
	const startParty = (0, import_react.useCallback)((year) => {
		setParty(true);
		setFx(true);
		setTrueMidnight(true);
		setPartySub("Here we go.");
		setNextYearLabel(String(year + 1));
		const midnight = new Date(year, 0, 1).getTime();
		if (partyTimer.current) window.clearInterval(partyTimer.current);
		partyTimer.current = window.setInterval(() => {
			const s = splitMs(Date.now() - midnight);
			setPartySub(`${pad2(s.hours)}h ${pad2(s.minutes)}m ${pad2(s.seconds)}s of ${year} so far`);
		}, 1e3);
	}, []);
	(0, import_react.useEffect)(() => {
		setMounted(true);
		targetRef.current = nextNewYear(/* @__PURE__ */ new Date());
		describe();
		const tick = () => {
			const now = /* @__PURE__ */ new Date();
			const remaining = targetRef.current.getTime() - now.getTime();
			if (remaining <= 0) {
				if (!partyStarted.current) {
					partyStarted.current = true;
					startParty(targetRef.current.getFullYear());
				}
				return;
			}
			const p = splitMs(remaining);
			const stamp = Math.ceil(remaining / 1e3);
			if (stamp !== lastSecond.current) {
				lastSecond.current = stamp;
				setParts(p);
				const pct = yearProgress(now);
				setProgress(pct);
				setProgressLabel(`${now.getFullYear()} is ${pct.toFixed(2)}% complete`);
				setClockNow(formatNow(now));
				if (p.seconds === 0) setSr(`${p.days} days, ${p.hours} hours and ${p.minutes} minutes until ${targetRef.current.getFullYear()}`);
				document.title = `${p.days}d ${pad2(p.hours)}:${pad2(p.minutes)}:${pad2(p.seconds)} · System Space`;
			}
		};
		tick();
		const interval = window.setInterval(tick, 250);
		return () => {
			window.clearInterval(interval);
			if (partyTimer.current) window.clearInterval(partyTimer.current);
		};
	}, [describe, startParty]);
	const onPreview = () => {
		setParty(true);
		setFx(true);
		setTrueMidnight(false);
		setPartySub("A sneak peek of midnight.");
		window.setTimeout(() => {
			if (!partyStarted.current) {
				setParty(false);
				setFx(false);
			}
		}, 6500);
	};
	const onNext = () => {
		if (partyTimer.current) window.clearInterval(partyTimer.current);
		partyStarted.current = false;
		targetRef.current = nextNewYear(/* @__PURE__ */ new Date());
		lastSecond.current = null;
		describe();
		setParty(false);
		setFx(false);
		setTrueMidnight(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SpaceStage, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppChrome, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fireworks, { active: fx }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto flex min-h-dvh w-full max-w-5xl flex-col items-center justify-center px-4 pb-16 pt-24 text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SolarSystem, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `mt-6 w-full transition-opacity duration-300 ${party ? "opacity-0" : "opacity-100"}`,
				children: [
					mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CountdownClock, { parts }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "countdown",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "unit",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "num",
								children: "--"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "unit-label",
								children: "Days"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-8 text-sm text-muted",
						children: ["Target: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "font-medium text-ink",
							children: targetLabel
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto mt-6 w-full max-w-md",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-1.5 overflow-hidden rounded-full bg-white/10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full rounded-full",
								style: {
									width: `${progress.toFixed(3)}%`,
									background: "linear-gradient(90deg, var(--color-ice), #e8e2ff, var(--color-sun))"
								}
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-xs tracking-wide text-muted",
							children: progressLabel
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 space-y-2 text-xs tracking-wide text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: meta }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: clockNow ? `Now: ${clockNow}` : "" })]
					}),
					!partyStarted.current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost mt-6",
						onClick: onPreview,
						children: "Preview the finale"
					}) : null
				]
			})]
		}),
		party ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "celebrate",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Happy New Year" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Here is to a brilliant year ahead." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: partySub
				}),
				trueMidnight ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "btn btn-ghost",
					onClick: onNext,
					children: ["Start counting to ", nextYearLabel]
				}) : null
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "sr-only",
			role: "status",
			"aria-live": "polite",
			children: sr
		})
	] });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeView, {});
}
//#endregion
export { Home as component };
