//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D_QAAgNB.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/dashboard",
			"/login",
			"/register",
			"/settings",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-BJrQiSnL.js",
			"/assets/react-SIfiwpqq.js",
			"/assets/theme-provider-Ow3Pa8MQ.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BJrQiSnL.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-B2sRw2Ip.js",
			"/assets/space-stage-BY4BmHAZ.js",
			"/assets/countdown-clock-BFLDLIgx.js"
		]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-DfXXp3cu.js",
			"/assets/profiles-hgtOSAR2.js",
			"/assets/image--F7Wu3RX.js"
		]
	},
	"/dashboard": {
		filePath: "/workspace/src/routes/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-CG6tl_1F.js",
			"/assets/profiles-hgtOSAR2.js",
			"/assets/auth-art-C24fJ2ei.js",
			"/assets/countdown-clock-BFLDLIgx.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-D2I3zv0q.js", "/assets/auth-form-CrpkPq50.js"]
	},
	"/register": {
		filePath: "/workspace/src/routes/register.tsx",
		children: void 0,
		preloads: ["/assets/register-Cr3RQKin.js", "/assets/auth-form-CrpkPq50.js"]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-CMAIDMpG.js",
			"/assets/client-C85fcJ4s.js",
			"/assets/profiles-hgtOSAR2.js",
			"/assets/image--F7Wu3RX.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
